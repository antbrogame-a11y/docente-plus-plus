
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyDLlynKUWbWO1LMIZwVwaOZC0YE01RWzhI",
  authDomain: "docente-plus-plus-577885-d9bd1.firebaseapp.com",
  projectId: "docente-plus-plus-577885-d9bd1",
  storageBucket: "docente-plus-plus-577885-d9bd1.firebasestorage.app",
  messagingSenderId: "840602960075",
  appId: "1:840602960075:web:022e8b12bfa3b3160f9b4e"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
