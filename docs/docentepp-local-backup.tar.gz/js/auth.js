
import { auth } from './firebase.js'; // Importa l'istanza di auth centralizzata
import { onAuthStateChanged, GoogleAuthProvider, signInWithPopup, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

export const initializeAuth = (onAuthStateReady) => {
    const authContainer = document.getElementById('auth-container');

    const updateAuthUI = (user) => {
        if (!authContainer) return;
        if (user) {
            authContainer.innerHTML = `
                <div class="user-info">
                    <span>${user.email}</span>
                    <button id="logout-btn">Logout</button>
                </div>
            `;
            document.getElementById('logout-btn').addEventListener('click', () => {
                signOut(auth).catch(error => console.error('Logout Error:', error));
            });
        } else {
            authContainer.innerHTML = '<button id="login-btn">Login con Google</button>';
            document.getElementById('login-btn').addEventListener('click', () => {
                const provider = new GoogleAuthProvider();
                signInWithPopup(auth, provider).catch(error => console.error('Login Error:', error));
            });
        }
    };

    onAuthStateChanged(auth, user => {
        updateAuthUI(user);
        if (onAuthStateReady) {
            onAuthStateReady(user);
        }
    });
};
