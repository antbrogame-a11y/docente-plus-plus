
import { initializeAuth } from './js/auth.js';
import { setupClassUI, cleanupClasses } from './js/classes.js';
// Importa qui altri moduli UI che creeremo, es: import { setupAgendaUI, cleanupAgenda } from './js/agenda.js';

const mainContent = document.getElementById('main-content');
const appStatus = document.getElementById('app-status');
const navLinks = document.querySelectorAll('nav a');

// Funzione per mostrare un messaggio di stato globale
const showStatus = (message) => {
    if (appStatus) appStatus.textContent = message;
};

// Mappa che collega l'ID della pagina alla sua funzione di setup e cleanup
const pageModules = {
    'agenda': { setup: null, cleanup: null }, // Ancora da implementare
    'classes': { setup: setupClassUI, cleanup: cleanupClasses },
    // Aggiungi qui altre pagine
};

let currentPageCleanup = null; // Funzione di cleanup per la pagina corrente

// Funzione per caricare il contenuto di una pagina
const loadPage = async (pageId) => {
    // 1. Esegui la pulizia della pagina precedente
    if (currentPageCleanup) {
        currentPageCleanup();
        currentPageCleanup = null;
    }

    showStatus('Caricamento...');
    try {
        const response = await fetch(`${pageId}.html`);
        if (!response.ok) throw new Error(`Pagina non trovata: ${pageId}`);
        mainContent.innerHTML = await response.text();
        document.title = `Docente++ | ${pageId.charAt(0).toUpperCase() + pageId.slice(1)}`;

        // 2. Esegui il setup del modulo per la nuova pagina
        const module = pageModules[pageId];
        if (module && module.setup) {
            module.setup(); // Chiama la funzione di setup (es. setupClassUI)
            currentPageCleanup = module.cleanup; // Salva la sua funzione di cleanup
        }

        showStatus(''); // Nasconde il messaggio di stato
    } catch (error) {
        console.error('Errore nel caricamento della pagina:', error);
        mainContent.innerHTML = `<p class="error-message">Errore nel caricare la pagina. ${error.message}</p>`;
        showStatus('Errore');
    }
};

// Gestione della navigazione
const handleNavigation = (e) => {
    e.preventDefault();
    const pageId = e.currentTarget.getAttribute('data-page');
    history.pushState({ pageId }, '', `#${pageId}`);
    loadPage(pageId);
    // Aggiorna la classe 'active' sui link
    navLinks.forEach(link => link.classList.toggle('active', link.getAttribute('data-page') === pageId));
};

navLinks.forEach(link => link.addEventListener('click', handleNavigation));

// Gestione dei pulsanti Avanti/Indietro del browser
window.addEventListener('popstate', (e) => {
    const pageId = e.state?.pageId || 'agenda'; // Default alla dashboard
    loadPage(pageId);
});

// --- Avvio dell'Applicazione ---
const startApp = (user) => {
    console.log("startApp chiamata con utente:", user);
    showStatus(''); // Rimuove "Avvio in corso..."
    const initialPage = window.location.hash.substring(1) || 'agenda';
    loadPage(initialPage);
    // Aggiorna la classe 'active' al primo caricamento
    navLinks.forEach(link => link.classList.toggle('active', link.getAttribute('data-page') === initialPage));
};

// Inizializza l'autenticazione e passa la funzione startApp come callback
showStatus('Avvio in corso...');
initializeAuth(startApp); // startApp verrà chiamata solo quando l'autenticazione è pronta
