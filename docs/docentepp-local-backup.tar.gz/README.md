# DocentEpp - Il Tuo Assistente Digitale per la Didattica

**DocentEpp** è una Progressive Web App (PWA) moderna e intuitiva, progettata per semplificare la vita dei docenti. Dimentica i registri cartacei e i file sparsi: DocentEpp centralizza la gestione delle classi, degli studenti e delle valutazioni in un unico posto, accessibile da qualsiasi dispositivo.

L'applicazione è costruita su un'architettura **Single Page Application (SPA)** e si appoggia interamente sulla piattaforma **Firebase**, garantendo un'esperienza utente fluida, veloce e reattiva.

---

## 🛠️ Stack Tecnologico

*   **Frontend**: HTML, CSS, JavaScript (Moduli ES)
*   **Backend & Infrastruttura**: Firebase
    *   **Firebase Hosting**: Per il deploy e la distribuzione dell'app.
    *   **Firebase Authentication**: Per la gestione degli utenti.
    *   **Cloud Firestore**: Come database NoSQL per i dati.
*   **Strumenti**: Firebase CLI

---

## 🚀 Quick Start (Guida per Sviluppatori)

Per avviare il progetto in locale, segui questi passaggi:

1.  **Installa la Firebase CLI**: Se non l'hai già fatto, installa l'interfaccia a riga di comando di Firebase a livello globale.
    ```bash
    npm install -g firebase-tools
    ```

2.  **Clona il repository**:
    ```bash
    git clone <URL_DEL_REPOSITORY>
    cd <NOME_DELLA_CARTELLA>
    ```

3.  **Login in Firebase**: Autenticati con il tuo account Google.
    ```bash
    firebase login
    ```

4.  **Avvia il server di sviluppo locale**: Questo comando avvierà un server che emula l'ambiente Firebase.
    ```bash
    firebase serve
    ```
    L'applicazione sarà accessibile all'indirizzo `http://localhost:5000`.

---

## 🗺️ Roadmap di Sviluppo

Il nostro obiettivo è continuare a migliorare DocentEpp. Abbiamo grandi piani per il futuro, tra cui:

*   **Visualizzazione grafica delle statistiche**
*   **Implementazione dell'orario scolastico**
*   **Sincronizzazione Cloud con Firebase**

Per una visione dettagliata dei prossimi passi, consulta la nostra [**Roadmap completa**](ROADMAP.md).

---

## 🤝 Come Contribuire

Sei uno sviluppatore e vuoi contribuire al progetto? Fantastico! Abbiamo preparato una [**Guida per Sviluppatori**](dev-guide.md) che contiene tutte le informazioni sull'architettura, le convenzioni di codice e le linee guida per iniziare.
